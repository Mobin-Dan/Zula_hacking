﻿$(window).on('load', function () {
    $('body').removeClass('loading');
    $('#preloader').fadeOut();
});

function isValidEmailAddress(emailAddress) {
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(emailAddress);
}

var waitingDialog = waitingDialog || (function ($) {
    'use strict';

    // Creating modal dialog's DOM
    var $dialog = $(
        '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
        '<div class="modal-dialog modal-m">' +
        '<div class="modal-content">' +
        '<div class="modal-body">' +
        '<div class="progress" style="margin-bottom:0;"><div class="progress-bar progress-bar-striped active" style="width: 100%;background-size: 100%"></div></div>' +
        '</div>' +
        '</div></div></div>');

    return {
        /**
         * Opens our dialog
         * @param message Custom message
         * @param options Custom options:
         * 				  options.dialogSize - bootstrap postfix for dialog size, e.g. "sm", "m";
         * 				  options.progressType - bootstrap postfix for progress bar type, e.g. "success", "warning".
         */
        show: function (message, options) {
            // Assigning defaults
            if (typeof options === 'undefined') {
                options = {};
            }
            if (typeof message === 'undefined') {
                message = 'Loading';
            }
            var settings = $.extend({
                dialogSize: 'm',
                progressType: '',
                onHide: null // This callback runs after the dialog was hidden
            }, options);

            // Configuring dialog
            $dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
            $dialog.find('.progress-bar').attr('class', 'progress-bar progress-bar-striped active');
            if (settings.progressType) {
                $dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
            }
            $dialog.find('h3').text(message);
            // Adding callbacks
            if (typeof settings.onHide === 'function') {
                $dialog.off('hidden.bs.modal').on('hidden.bs.modal', function (e) {
                    settings.onHide.call($dialog);
                });
            }
            // Opening dialog
            $dialog.modal();
        },
        /**
         * Closes dialog
         */
        hide: function () {
            $dialog.modal('hide');
        }
    };

})(jQuery);


$(document).ready(function() {
    $('.lazy').Lazy({
        scrollDirection: 'vertical',
        effect: 'fadeIn',
        visibleOnly: true,
        onError: function (element) {
            console.log('error loading ' + element.data('src'));
        }
    });

    if ($(".charge-buttons .col-sm-3").length === 3) {
        $(".charge-buttons .col-sm-3").css("float", "none");
    }
    
    if (localStorage.getItem('ageConfirmation') !== undefined && localStorage.getItem('ageConfirmation')  !== "true") {
        $('#ageControlModal').modal({
            show: true,
            keyboard: false,
            backdrop: 'static'
        });
    }
});

//toggle menu
$(".toggleMenu").on("click", function(e) {
    e.preventDefault();
    $("section.menu ul").slideToggle();
});

$('#downloadModal').on('shown.bs.modal', function (e) {
    $(".lazy").Lazy();
});

$('#btnConfirmAge').on('click', function (e) {
    e.preventDefault();
    localStorage.setItem('ageConfirmation', 'true');
    $('#ageControlModal').modal('hide');
});

$('#btnRejectAge').on('click', function (e) {
    e.preventDefault();
    alert(txtAgeError);
    return;
});

//Gift Code
$('#btnGiftCode').on('click', function (e) {
    e.preventDefault();
    var code = $('#txtGiftCode').val();
    if (code.length !== 10) {
        alert('Lütfen geçerli bir kod giriniz.');
        return;
    }

    var giftCodeToken = $('input[name="__RequestVerificationToken"]').val();
    $.ajax({
        url: 'profil/hediye-kodu',
        //contentType: 'application/json; charset=utf-8',
        type: 'POST',
        data: {
            code: code,
            __RequestVerificationToken: giftCodeToken
        },
        success: function (result) {
            $('.giftCodeModal .modal-body').css('background-position', '-1500px');
            $('.giftcode-form').addClass('hidden');
            switch (result) {
                case "ZLA.CampaignInvalidCode":
                    $('.giftcode-result.error').removeClass('hidden');
                    break;
                case "ZLA.CampaignMaxLimit":
                    $('.giftcode-result.error').removeClass('hidden');
                    break;
                case "ZLA.CampaignTurkcellItem":
                    $('.giftcode-result.success').removeClass('hidden');
                    break;
                case "ZLA.CampaignPaycellItem":
                    $('.giftcode-result.success').removeClass('hidden');
                    break;
            }
        }
    });

    return;
});

$('#btnTryGiftCodeAgain').on('click', function (e) {
    e.preventDefault();
    $('.giftcode-result.error').addClass('hidden');
    $('.giftcode-form').removeClass('hidden');
    $('.giftCodeModal .modal-body').css('background-position', 'right center');
    $('#txtGiftCode').val('');
});


$('#txtSubject').on("keyup", function () {
    var currentValue = $(this).val();
    $(this).val(currentValue.replace(/(<([^>]+)>)/ig, ""));
});

$('#txtDetail').on("keyup", function () {
    var currentValue = $(this).val();
    $(this).val(currentValue.replace(/(<([^>]+)>)/ig, ""));
});

$('#txtMsg').on("keyup", function () {
    var currentValue = $(this).val();
    $(this).val(currentValue.replace(/(<([^>]+)>)/ig, ""));
});

// Home Banners
$('.home-banner').each(function () {
    if ($(this).attr('src') == '#') {
        $(this).parent('a').remove();
    }
});

$('.home-banner').css('display', 'block');

$('.carousel-inner').each(function () {
    $(this).find('.item').first().addClass('active');
});
